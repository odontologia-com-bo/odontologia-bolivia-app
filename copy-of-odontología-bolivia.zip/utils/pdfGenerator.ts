
import { jsPDF } from 'jspdf';
import 'jspdf-autotable'; // Ensure this is imported for autoTable to be available
import { GeneratedBudget } from '../types';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

// Extend jsPDF interface to include autoTable
declare module 'jspdf' {
  interface jsPDF {
    autoTable: (options: any) => jsPDF;
  }
}

export const generateBudgetPDF = (budget: GeneratedBudget, clinicName: string, clinicContact: string): void => {
  const doc = new jsPDF();

  // Header
  doc.setFontSize(20);
  doc.setTextColor(40, 58, 117); // Dark Blue
  doc.text(clinicName, 14, 22);
  doc.setFontSize(10);
  doc.setTextColor(100);
  doc.text(`Contacto: ${clinicContact}`, 14, 30);
  
  // Budget Info
  doc.setFontSize(14);
  doc.setTextColor(40);
  doc.text('Presupuesto Dental Estimado', 14, 45);
  doc.setFontSize(10);
  doc.text(`Fecha: ${format(new Date(budget.createdAt), 'dd/MM/yyyy HH:mm', { locale: es })}`, 14, 52);
  doc.text(`Paciente: ${budget.patientName || 'No especificado'}`, 14, 59);

  // Table
  const tableColumn = ["Servicio", "Cantidad", "Precio Unitario (Bs.)", "Subtotal (Bs.)"];
  const tableRows: (string | number)[][] = [];

  budget.items.forEach(item => {
    const itemData = [
      item.name,
      item.quantity,
      item.price.toFixed(2),
      (item.price * item.quantity).toFixed(2)
    ];
    tableRows.push(itemData);
  });

  doc.autoTable({
    startY: 70,
    head: [tableColumn],
    body: tableRows,
    theme: 'striped',
    headStyles: { fillColor: [22, 160, 133] }, // Teal color for header
    styles: { font: 'helvetica', fontSize: 10 },
  });

  // Total
  const finalY = (doc as any).lastAutoTable.finalY || 100; // Get Y position after table
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Total Estimado:', 14, finalY + 10);
  doc.text(`${budget.totalAmount.toFixed(2)} Bs.`, 150, finalY + 10, { align: 'right' });

  // Footer Note
  doc.setFontSize(8);
  doc.setTextColor(150);
  doc.text(
    'Este es un presupuesto inicial y puede estar sujeto a cambios tras una evaluación dental completa.',
    14,
    doc.internal.pageSize.height - 20
  );
  doc.text(
    `Para cualquier consulta, por favor contacte a ${clinicName}.`,
    14,
    doc.internal.pageSize.height - 15
  );

  doc.save(`Presupuesto_${budget.patientName || 'Dental'}_${format(new Date(budget.createdAt), 'yyyyMMdd')}.pdf`);
};
