
import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import { DentalService, ServiceCategory, Appointment, GeneratedBudget, PatientInfo, UploadedFile } from '../types';
import { INITIAL_SERVICE_CATEGORIES, ADMIN_PASSWORD } from '../constants';

interface AppContextType {
  serviceCategories: ServiceCategory[];
  updateServicePrice: (serviceId: string, newPrice: number) => void;
  appointments: Appointment[];
  addAppointment: (appointment: Appointment) => void;
  budgets: GeneratedBudget[];
  addBudget: (budget: GeneratedBudget) => void;
  isAdminLoggedIn: boolean;
  loginAdmin: (password: string) => boolean;
  logoutAdmin: () => void;
  patientInfo: PatientInfo | null;
  updatePatientInfo: (info: PatientInfo) => void;
  uploadedFiles: UploadedFile[];
  addUploadedFile: (file: UploadedFile) => void;
  removeUploadedFile: (fileId: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Helper to get initial state from localStorage
const getInitialState = <T,>(key: string, defaultValue: T): T => {
  try {
    const item = window.localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch (error) {
    console.warn(`Error reading localStorage key "${key}":`, error);
    return defaultValue;
  }
};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [serviceCategories, setServiceCategories] = useState<ServiceCategory[]>(() => {
    // Attempt to load from localStorage, otherwise use initial constants
    const storedCategories = getInitialState<ServiceCategory[] | null>('serviceCategories', null);
    if (storedCategories) return storedCategories;

    // If nothing in localStorage, initialize properly
    return INITIAL_SERVICE_CATEGORIES.map(category => ({
      ...category,
      services: category.services.map(service => ({ ...service }))
    }));
  });

  const [appointments, setAppointments] = useState<Appointment[]>(() => getInitialState<Appointment[]>('appointments', []));
  const [budgets, setBudgets] = useState<GeneratedBudget[]>(() => getInitialState<GeneratedBudget[]>('budgets', []));
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(() => getInitialState<boolean>('isAdminLoggedIn', false));
  const [patientInfo, setPatientInfo] = useState<PatientInfo | null>(() => getInitialState<PatientInfo | null>('patientInfo', null));
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>(() => {
    // For files, we can't store the File object itself in localStorage easily.
    // So we just initialize to empty. A real app might store metadata.
    return [];
  });


  // Persist state to localStorage
  useEffect(() => {
    localStorage.setItem('serviceCategories', JSON.stringify(serviceCategories));
  }, [serviceCategories]);

  useEffect(() => {
    localStorage.setItem('appointments', JSON.stringify(appointments));
  }, [appointments]);

  useEffect(() => {
    localStorage.setItem('budgets', JSON.stringify(budgets));
  }, [budgets]);
  
  useEffect(() => {
    localStorage.setItem('isAdminLoggedIn', JSON.stringify(isAdminLoggedIn));
  }, [isAdminLoggedIn]);

  useEffect(() => {
    localStorage.setItem('patientInfo', JSON.stringify(patientInfo));
  }, [patientInfo]);


  const updateServicePrice = (serviceId: string, newPrice: number) => {
    setServiceCategories(prevCategories =>
      prevCategories.map(category => ({
        ...category,
        services: category.services.map(service =>
          service.id === serviceId ? { ...service, price: newPrice } : service
        ),
      }))
    );
  };

  const addAppointment = (appointment: Appointment) => {
    setAppointments(prev => [...prev, appointment]);
  };

  const addBudget = (budget: GeneratedBudget) => {
    setBudgets(prev => [...prev, budget]);
  };

  const loginAdmin = (password: string): boolean => {
    if (password === ADMIN_PASSWORD) {
      setIsAdminLoggedIn(true);
      return true;
    }
    return false;
  };

  const logoutAdmin = () => {
    setIsAdminLoggedIn(false);
  };

  const updatePatientInfo = (info: PatientInfo) => {
    setPatientInfo(info);
  };

  const addUploadedFile = (file: UploadedFile) => {
    setUploadedFiles(prev => [...prev, file]);
  };
  
  const removeUploadedFile = (fileId: string) => {
    setUploadedFiles(prev => prev.filter(f => f.id !== fileId));
    // Note: Need to revoke object URL if it exists and this component managed its lifecycle
    const fileToRemove = uploadedFiles.find(f => f.id === fileId);
    if (fileToRemove && fileToRemove.previewUrl) {
        URL.revokeObjectURL(fileToRemove.previewUrl);
    }
  };


  return (
    <AppContext.Provider
      value={{
        serviceCategories,
        updateServicePrice,
        appointments,
        addAppointment,
        budgets,
        addBudget,
        isAdminLoggedIn,
        loginAdmin,
        logoutAdmin,
        patientInfo,
        updatePatientInfo,
        uploadedFiles,
        addUploadedFile,
        removeUploadedFile
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
