
import React, { useState, ChangeEvent, FormEvent, useEffect } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { PatientInfo, UploadedFile } from '../types';
import { WHATSAPP_NUMBER, CONTACT_EMAIL, CLINIC_NAME, CLINIC_ADDRESS } from '../constants';

const ProfilePage: React.FC = () => {
  const { patientInfo, updatePatientInfo, addUploadedFile, uploadedFiles } = useAppContext();
  const [localPatientInfo, setLocalPatientInfo] = useState<PatientInfo>(
    patientInfo || { name: '', age: '', phone: '', email: '' }
  );
  const [editMode, setEditMode] = useState(!patientInfo);
  const [fileType, setFileType] = useState<'prescription' | 'clinical_image'>('prescription');

  useEffect(() => {
    if (patientInfo) {
      setLocalPatientInfo(patientInfo);
      setEditMode(false);
    }
  }, [patientInfo]);

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setLocalPatientInfo(prev => ({ ...prev, [name]: value }));
  };

  const handlePatientInfoSubmit = (e: FormEvent) => {
    e.preventDefault();
    updatePatientInfo(localPatientInfo);
    setEditMode(false);
    alert('Información del paciente guardada.');
  };

  const handleFileUpload = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const newFile: UploadedFile = {
        id: new Date().toISOString(),
        name: file.name,
        type: fileType,
        file: file,
        previewUrl: URL.createObjectURL(file) // Create a preview URL for images
      };
      addUploadedFile(newFile);
      alert(`Archivo "${file.name}" subido como ${fileType === 'prescription' ? 'receta' : 'imagen clínica'}.`);
      e.target.value = ''; // Reset file input
    }
  };

  return (
    <div className="p-4 max-w-lg mx-auto">
      <h1 className="text-2xl font-bold text-blue-700 mb-6 text-center">Perfil y Contacto</h1>

      {/* Contact Info Section */}
      <div className="bg-white p-6 rounded-lg shadow mb-6">
        <h2 className="text-xl font-semibold text-gray-800 mb-3">Información de Contacto</h2>
        <p className="text-gray-600"><strong>Clínica:</strong> {CLINIC_NAME}</p>
        <p className="text-gray-600"><strong>Dirección:</strong> {CLINIC_ADDRESS}</p>
        <p className="text-gray-600"><strong>Email:</strong> <a href={`mailto:${CONTACT_EMAIL}`} className="text-blue-500 hover:underline">{CONTACT_EMAIL}</a></p>
        <p className="text-gray-600"><strong>WhatsApp:</strong> 
          <a 
            href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(`Hola ${CLINIC_NAME}, me gustaría hacer una consulta.`)}`} 
            target="_blank" 
            rel="noopener noreferrer"
            className="ml-1 bg-green-500 hover:bg-green-600 text-white text-sm font-semibold py-1 px-3 rounded-full inline-flex items-center"
          >
            <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20"><path d="M13.588 11.044c-.22.126-.78.388-1.044.388-.264 0-.572-.09-.936-.454-.364-.364-.936-.936-1.572-1.572-.636-.636-1.208-1.208-1.572-1.572-.364-.364-.454-.672-.454-.936 0-.264.262-.824.388-1.044.126-.22.09-.454-.09-.636L6.3 3.974c-.18-.18-.454-.22-.636-.09-.18.126-.936.454-1.2.72-.264.264-.454.672-.454.936 0 .454.22.9.454 1.32.22.454.72.9.9.9.22.22.454.454.72.72.636.636 1.208 1.208 1.752 1.752.544.544 1.164 1.044 1.752 1.572.588.528 1.164.9 1.752 1.2.588.264 1.164.454 1.752.454.588 0 1.164-.18 1.572-.454.408-.264.72-.72.9-.9.22-.22.454-.454.72-.72.264-.264.454-.454.454-.9 0-.264-.18-.588-.454-.9zm6.412-8.044c-2.22-2.22-5.836-2.22-8.056 0-2.22 2.22-2.22 5.836 0 8.056 2.22 2.22 5.836 2.22 8.056 0 2.22-2.22 2.22-5.836 0-8.056zm-1.128 6.928c-.22.22-.454.454-.72.72-.264.264-.454.454-.72.454-.264 0-.588-.18-.9-.454-.364-.264-.72-.72-.9-.9-.22-.22-.454-.454-.72-.72-.636-.636-1.208-1.208-1.752-1.752-.544-.544-1.044-1.164-1.572-1.752-.528-.588-.9-1.164-1.2-1.752-.264-.588-.454-1.164-.454-1.752 0-.588.18-1.164.454-1.572.264-.408.72-.72.9-.9.22-.22.454-.454.72-.72.264-.264.454-.454.9-.454.264 0 .588.18.9.454.364.264.72.72.9.9.22.22.454.454.72.72.636.636 1.208 1.208 1.752 1.752.544.544 1.164 1.044 1.752 1.572.588.528.9 1.164 1.2 1.752.264.588.454 1.164.454 1.752 0 .588-.18 1.164-.454 1.572z"></path></svg>
            Contactar
          </a>
        </p>
      </div>

      {/* Patient Registration/Info Section */}
      <div className="bg-white p-6 rounded-lg shadow mb-6">
        <div className="flex justify-between items-center mb-3">
          <h2 className="text-xl font-semibold text-gray-800">Información del Paciente</h2>
          {!editMode && (
            <button onClick={() => setEditMode(true)} className="text-sm text-blue-500 hover:underline">Editar</button>
          )}
        </div>
        {editMode ? (
          <form onSubmit={handlePatientInfoSubmit} className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">Nombre Completo</label>
              <input type="text" name="name" id="name" value={localPatientInfo.name} onChange={handleInputChange} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"/>
            </div>
            <div>
              <label htmlFor="age" className="block text-sm font-medium text-gray-700">Edad</label>
              <input type="number" name="age" id="age" value={localPatientInfo.age} onChange={handleInputChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"/>
            </div>
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700">Teléfono</label>
              <input type="tel" name="phone" id="phone" value={localPatientInfo.phone} onChange={handleInputChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"/>
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
              <input type="email" name="email" id="email" value={localPatientInfo.email} onChange={handleInputChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"/>
            </div>
            <div className="flex gap-2">
              <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-md focus:outline-none focus:shadow-outline transition duration-150">Guardar</button>
              {patientInfo && <button type="button" onClick={() => { setEditMode(false); setLocalPatientInfo(patientInfo); }} className="w-full bg-gray-200 hover:bg-gray-300 text-gray-700 font-semibold py-2 px-4 rounded-md focus:outline-none focus:shadow-outline transition duration-150">Cancelar</button>}
            </div>
          </form>
        ) : (
          patientInfo ? (
            <div className="space-y-1 text-gray-600">
              <p><strong>Nombre:</strong> {patientInfo.name}</p>
              <p><strong>Edad:</strong> {patientInfo.age || 'No especificada'}</p>
              <p><strong>Teléfono:</strong> {patientInfo.phone || 'No especificado'}</p>
              <p><strong>Email:</strong> {patientInfo.email || 'No especificado'}</p>
            </div>
          ) : (
            <p className="text-gray-500">No hay información de paciente registrada. <button onClick={() => setEditMode(true)} className="text-blue-500 hover:underline">Registrar ahora</button>.</p>
          )
        )}
      </div>

      {/* File Upload Section */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-semibold text-gray-800 mb-3">Subir Documentos</h2>
        <div className="mb-4">
            <label htmlFor="fileType" className="block text-sm font-medium text-gray-700">Tipo de archivo</label>
            <select 
                id="fileType" 
                name="fileType" 
                value={fileType}
                onChange={(e) => setFileType(e.target.value as 'prescription' | 'clinical_image')}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
            >
                <option value="prescription">Receta Odontológica</option>
                <option value="clinical_image">Imagen Clínica de Referencia</option>
            </select>
        </div>
        <div>
          <label htmlFor="file-upload" className="block text-sm font-medium text-gray-700 mb-1">
            {fileType === 'prescription' ? 'Capturar o subir receta' : 'Subir imagen clínica'}
          </label>
          <input 
            id="file-upload" 
            name="file-upload" 
            type="file" 
            accept="image/*,.pdf" // Accept images and PDF for prescriptions
            capture={fileType === 'prescription' ? 'environment' : undefined} // Suggest environment camera for prescriptions
            onChange={handleFileUpload}
            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
          />
           <p className="mt-1 text-xs text-gray-500">
            {fileType === 'prescription' ? 'Puede tomar una foto de su receta o subir un archivo (imagen/PDF).' : 'Suba imágenes clínicas relevantes (JPG, PNG, etc.).'}
          </p>
        </div>
        {uploadedFiles.length > 0 && (
          <div className="mt-4">
            <h3 className="text-md font-semibold text-gray-700">Archivos Subidos:</h3>
            <ul className="list-disc list-inside text-sm text-gray-600">
              {uploadedFiles.map(f => (
                <li key={f.id}>
                  {f.name} ({f.type === 'prescription' ? 'Receta' : 'Imagen Clínica'})
                  {f.previewUrl && f.file.type.startsWith("image/") && (
                    <img src={f.previewUrl} alt={`Vista previa de ${f.name}`} className="mt-1 h-16 w-16 object-cover rounded"/>
                  )}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfilePage;
