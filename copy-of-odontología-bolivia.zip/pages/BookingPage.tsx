
import React, { useState } from 'react';
import CalendarView from '../components/CalendarView';
import { useAppContext } from '../contexts/AppContext';
import { Appointment } from '../types';
import { format } from 'date-fns';
import { AVAILABLE_TIME_SLOTS, CLINIC_NAME } from '../constants';

const BookingPage: React.FC = () => {
  const { addAppointment } = useAppContext();
  const [selectedDate, setSelectedDate] = useState<Date | null>(new Date());
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [patientName, setPatientName] = useState('');
  const [patientContact, setPatientContact] = useState('');
  const [confirmationMessage, setConfirmationMessage] = useState<string | null>(null);

  const handleDateSelect = (date: Date) => {
    setSelectedDate(date);
    setSelectedTime(null); // Reset time when date changes
    setConfirmationMessage(null);
  };

  const handleTimeSelect = (time: string) => {
    setSelectedTime(time);
    setConfirmationMessage(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedDate && selectedTime && patientName) {
      const newAppointment: Appointment = {
        id: new Date().toISOString(),
        date: format(selectedDate, 'yyyy-MM-dd'),
        time: selectedTime,
        patientName,
        patientContact,
      };
      addAppointment(newAppointment);
      // Simulate Google Calendar sync and notification
      setConfirmationMessage(`¡Cita agendada para ${patientName} el ${format(selectedDate, 'dd/MM/yyyy')} a las ${selectedTime}hs! Se ha notificado al paciente y la cita ha sido enviada al calendario del administrador.`);
      
      // Reset form
      setSelectedDate(new Date());
      setSelectedTime(null);
      setPatientName('');
      setPatientContact('');
    } else {
      alert('Por favor, complete todos los campos requeridos: fecha, hora y nombre del paciente.');
    }
  };

  return (
    <div className="p-4 max-w-lg mx-auto">
      <h1 className="text-2xl font-bold text-blue-700 mb-6 text-center">Agendar Cita en {CLINIC_NAME}</h1>
      
      {confirmationMessage && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
          <strong className="font-bold">¡Éxito! </strong>
          <span className="block sm:inline">{confirmationMessage}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="patientName" className="block text-sm font-medium text-gray-700 mb-1">Nombre del Paciente</label>
          <input
            type="text"
            id="patientName"
            value={patientName}
            onChange={(e) => setPatientName(e.target.value)}
            required
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
          />
        </div>
        <div>
          <label htmlFor="patientContact" className="block text-sm font-medium text-gray-700 mb-1">Contacto (Teléfono/Email - Opcional)</label>
          <input
            type="text"
            id="patientContact"
            value={patientContact}
            onChange={(e) => setPatientContact(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
          />
        </div>
        
        <CalendarView 
          selectedDate={selectedDate} 
          onDateSelect={handleDateSelect}
          availableSlots={AVAILABLE_TIME_SLOTS}
          selectedSlot={selectedTime}
          onSlotSelect={handleTimeSelect}
        />

        {selectedDate && selectedTime && (
           <p className="text-center text-gray-600 mt-2">
            Cita seleccionada: {format(selectedDate, 'dd/MM/yyyy')} a las {selectedTime}
          </p>
        )}

        <button 
          type="submit"
          disabled={!selectedDate || !selectedTime || !patientName}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-md focus:outline-none focus:shadow-outline transition duration-150 ease-in-out disabled:opacity-50"
        >
          Confirmar Cita
        </button>
      </form>
      <p className="mt-4 text-xs text-gray-500 text-center">
        Nota: La integración con Google Calendar y notificaciones son simuladas en esta versión.
      </p>
    </div>
  );
};

export default BookingPage;
