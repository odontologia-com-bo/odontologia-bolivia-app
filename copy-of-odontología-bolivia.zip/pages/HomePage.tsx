
import React from 'react';
import { Link } from 'react-router-dom';
import { CLINIC_NAME } from '../constants';

const HomePage: React.FC = () => {
  return (
    <div className="p-4 md:p-8 min-h-full flex flex-col items-center justify-center text-center bg-gradient-to-br from-sky-400 to-blue-600 text-white">
      <header className="mb-12">
        <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl">
          <span className="text-blue-600 text-4xl font-bold">OB</span> 
          {/* Placeholder for odontologia.com.bo logo */}
        </div>
        <h1 className="text-4xl md:text-5xl font-bold mb-2">{CLINIC_NAME}</h1>
        <p className="text-lg md:text-xl text-sky-100">Tu sonrisa, nuestra prioridad.</p>
      </header>

      <section className="grid grid-cols-1 sm:grid-cols-2 gap-6 w-full max-w-lg">
        <Link to="/booking" className="bg-white text-blue-600 p-6 rounded-lg shadow-lg hover:bg-sky-50 transition-colors duration-200">
          <h2 className="text-xl font-semibold mb-2">Agendar Cita</h2>
          <p className="text-sm text-gray-600">Encuentra un horario conveniente para tu próxima visita.</p>
        </Link>
        <Link to="/budget" className="bg-white text-blue-600 p-6 rounded-lg shadow-lg hover:bg-sky-50 transition-colors duration-200">
          <h2 className="text-xl font-semibold mb-2">Presupuesto Dental</h2>
          <p className="text-sm text-gray-600">Obtén una estimación de costos para nuestros servicios.</p>
        </Link>
      </section>

      <footer className="mt-12 text-sm text-sky-200">
        <p>&copy; {new Date().getFullYear()} {CLINIC_NAME}. Todos los derechos reservados.</p>
        <p>Simulación de App Odontológica</p>
      </footer>
    </div>
  );
};

export default HomePage;
