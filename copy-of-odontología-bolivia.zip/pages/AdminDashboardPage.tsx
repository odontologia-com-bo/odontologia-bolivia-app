
import React, { useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { DentalService, Appointment, GeneratedBudget } from '../types';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';


const AdminDashboardPage: React.FC = () => {
  const { 
    serviceCategories, 
    updateServicePrice, 
    appointments, 
    budgets, 
    logoutAdmin 
  } = useAppContext();

  const navigate = useNavigate();
  const [editingPrices, setEditingPrices] = useState<Record<string, string>>({});
  const [activeTab, setActiveTab] = useState<'prices' | 'appointments' | 'budgets'>('appointments');

  const handlePriceChange = (serviceId: string, value: string) => {
    setEditingPrices(prev => ({ ...prev, [serviceId]: value }));
  };

  const handleSavePrice = (serviceId: string) => {
    const newPrice = parseFloat(editingPrices[serviceId]);
    if (!isNaN(newPrice) && newPrice >= 0) {
      updateServicePrice(serviceId, newPrice);
      // Remove from editing state or update with formatted new price
      setEditingPrices(prev => {
        const updated = { ...prev };
        delete updated[serviceId];
        return updated;
      });
      alert(`Precio para el servicio ${serviceId} actualizado a ${newPrice} Bs.`);
    } else {
      alert("Por favor, ingrese un precio válido.");
    }
  };

  const handleLogout = () => {
    logoutAdmin();
    navigate('/admin-login');
  };
  
  const TabButton: React.FC<{tabName: 'prices' | 'appointments' | 'budgets'; label: string}> = ({ tabName, label }) => (
    <button
      onClick={() => setActiveTab(tabName)}
      className={`px-4 py-2 text-sm font-medium rounded-t-lg transition-colors
        ${activeTab === tabName 
          ? 'bg-blue-600 text-white' 
          : 'text-blue-500 hover:bg-blue-100 hover:text-blue-700'}`}
    >
      {label}
    </button>
  );


  return (
    <div className="p-4 max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-blue-700">Panel de Administración</h1>
        <button 
          onClick={handleLogout}
          className="bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-md text-sm"
        >
          Cerrar Sesión
        </button>
      </div>

      <div className="mb-4 border-b border-gray-300">
        <TabButton tabName="appointments" label="Agenda de Citas" />
        <TabButton tabName="budgets" label="Historial de Presupuestos" />
        <TabButton tabName="prices" label="Gestionar Precios" />
      </div>

      {/* Content for tabs */}
      <div className="bg-white p-4 sm:p-6 rounded-b-lg rounded-tr-lg shadow">
        {activeTab === 'prices' && (
          <div>
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Editar Precios de Servicios</h2>
            {serviceCategories.map(category => (
              <div key={category.id} className="mb-6">
                <h3 className="text-lg font-semibold text-sky-700 mb-2">{category.name}</h3>
                <ul className="space-y-2">
                  {category.services.map(service => (
                    <li key={service.id} className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-3 bg-gray-50 rounded-md shadow-sm">
                      <span className="text-gray-700 mb-2 sm:mb-0">{service.name} (Actual: {service.price} Bs.)</span>
                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          step="0.01"
                          value={editingPrices[service.id] !== undefined ? editingPrices[service.id] : service.price.toString()}
                          onChange={(e) => handlePriceChange(service.id, e.target.value)}
                          className="w-24 px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                        />
                        <button
                          onClick={() => handleSavePrice(service.id)}
                          className="bg-green-500 hover:bg-green-600 text-white text-xs font-semibold py-1 px-3 rounded-md"
                        >
                          Guardar
                        </button>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
            <p className="mt-4 text-xs text-gray-500">
              Nota: Los cambios de precios se guardan localmente en esta simulación.
            </p>
          </div>
        )}

        {activeTab === 'appointments' && (
          <div>
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Agenda de Citas</h2>
            {appointments.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Hora</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Paciente</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contacto</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {appointments.sort((a,b) => new Date(a.date+'T'+a.time).getTime() - new Date(b.date+'T'+b.time).getTime() ).map(app => (
                      <tr key={app.id}>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700">{format(new Date(app.date+'T00:00:00'), 'dd MMM yyyy', { locale: es })}</td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700">{app.time}</td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700">{app.patientName}</td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">{app.patientContact || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-500">No hay citas agendadas.</p>
            )}
             <p className="mt-4 text-xs text-gray-500">
              Nota: Las citas se guardan localmente en esta simulación. La integración con Firebase se simula.
            </p>
          </div>
        )}

        {activeTab === 'budgets' && (
          <div>
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Historial de Presupuestos Generados</h2>
            {budgets.length > 0 ? (
              <ul className="space-y-3">
                {budgets.sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(budget => (
                  <li key={budget.id} className="p-3 bg-gray-50 rounded-md shadow-sm">
                    <div className="flex justify-between items-center mb-1">
                      <p className="text-sm text-gray-600">
                        <span className="font-semibold">{budget.patientName || "Paciente Anónimo"}</span> - {format(new Date(budget.createdAt), 'dd MMM yyyy, HH:mm', { locale: es })}
                      </p>
                      <p className="text-sm font-bold text-blue-600">{budget.totalAmount} Bs.</p>
                    </div>
                    <ul className="text-xs text-gray-500 list-disc list-inside ml-2">
                      {budget.items.map(item => (
                        <li key={item.id}>{item.name} (x{item.quantity}) - {item.price * item.quantity} Bs.</li>
                      ))}
                    </ul>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-gray-500">No hay presupuestos generados.</p>
            )}
             <p className="mt-4 text-xs text-gray-500">
              Nota: Los presupuestos se guardan localmente en esta simulación.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboardPage;
