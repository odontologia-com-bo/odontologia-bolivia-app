
import React, { useState, useMemo } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { DentalService, SelectedService, GeneratedBudget } from '../types';
import ServiceCategoryComponent from '../components/ServiceCategory';
import { generateBudgetPDF } from '../utils/pdfGenerator';
import { CONTACT_EMAIL, CLINIC_NAME } from '../constants';

const BudgetPage: React.FC = () => {
  const { serviceCategories, addBudget } = useAppContext();
  const [selectedServices, setSelectedServices] = useState<SelectedService[]>([]);
  const [patientName, setPatientName] = useState<string>('');

  const handleServiceToggle = (service: DentalService, quantity: number) => {
    setSelectedServices(prev => {
      const existing = prev.find(s => s.id === service.id);
      if (quantity === 0) {
        return prev.filter(s => s.id !== service.id);
      }
      if (existing) {
        return prev.map(s => s.id === service.id ? { ...s, quantity } : s);
      }
      return [...prev, { ...service, quantity }];
    });
  };

  const totalAmount = useMemo(() => {
    return selectedServices.reduce((sum, s) => sum + (s.price * s.quantity), 0);
  }, [selectedServices]);

  const handleGenerateBudget = () => {
    if (selectedServices.length === 0) {
      alert("Por favor, seleccione al menos un servicio.");
      return;
    }
    const newBudget: GeneratedBudget = {
      id: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      items: selectedServices,
      totalAmount,
      patientName: patientName || "Paciente Anónimo"
    };
    addBudget(newBudget); // Simulate saving budget
    generateBudgetPDF(newBudget, CLINIC_NAME, CONTACT_EMAIL);
    alert(`Presupuesto generado y exportado como PDF. Total: ${totalAmount} Bs.`);
  };

  const handleEmailBudget = () => {
     if (selectedServices.length === 0) {
      alert("Por favor, seleccione al menos un servicio para enviar por correo.");
      return;
    }
    const subject = `Presupuesto Dental de ${CLINIC_NAME}`;
    let body = `Estimado/a ${patientName || 'Paciente'},\n\nAdjunto encontrará un resumen de su presupuesto dental:\n\n`;
    selectedServices.forEach(item => {
      body += `- ${item.name} (x${item.quantity}): ${item.price * item.quantity} Bs.\n`;
    });
    body += `\nTotal Estimado: ${totalAmount} Bs.\n\n`;
    body += `Para confirmar o discutir este presupuesto, por favor contáctenos.\n\nSaludos cordiales,\nEl equipo de ${CLINIC_NAME}`;
    
    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    alert("Se ha abierto su cliente de correo para enviar el presupuesto. Si no tiene un PDF, genere uno primero.");
  };

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold text-blue-700 mb-6 text-center">Generador de Presupuesto Inicial</h1>
      
      <div className="mb-4">
        <label htmlFor="patientNameBudget" className="block text-sm font-medium text-gray-700 mb-1">Nombre del Paciente (Opcional)</label>
        <input
          type="text"
          id="patientNameBudget"
          value={patientName}
          onChange={(e) => setPatientName(e.target.value)}
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
          placeholder="Ej: Juan Pérez"
        />
      </div>

      {serviceCategories.map(category => (
        <ServiceCategoryComponent
          key={category.id}
          categoryName={category.name}
          services={category.services}
          selectedServices={selectedServices}
          onServiceToggle={handleServiceToggle}
        />
      ))}

      {selectedServices.length > 0 && (
        <div className="mt-8 p-6 bg-sky-50 rounded-lg shadow">
          <h2 className="text-xl font-semibold text-blue-700 mb-4">Resumen del Presupuesto</h2>
          <ul className="space-y-2 mb-4">
            {selectedServices.map(s => (
              <li key={s.id} className="flex justify-between text-gray-700">
                <span>{s.name} (x{s.quantity})</span>
                <span>{s.price * s.quantity} Bs.</span>
              </li>
            ))}
          </ul>
          <div className="flex justify-between items-center border-t pt-4">
            <span className="text-lg font-bold text-gray-800">Total Estimado:</span>
            <span className="text-2xl font-bold text-blue-600">{totalAmount} Bs.</span>
          </div>
          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <button
              onClick={handleGenerateBudget}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:shadow-outline transition duration-150 ease-in-out"
            >
              Exportar Presupuesto a PDF
            </button>
            <button
              onClick={handleEmailBudget}
              className="flex-1 bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:shadow-outline transition duration-150 ease-in-out"
            >
              Enviar por Email
            </button>
          </div>
        </div>
      )}
      <p className="mt-4 text-xs text-gray-500 text-center">
        Este es un presupuesto inicial y puede variar según el diagnóstico final.
      </p>
    </div>
  );
};

export default BudgetPage;
