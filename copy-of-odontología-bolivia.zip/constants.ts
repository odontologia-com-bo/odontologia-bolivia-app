
import { ServiceCategory }  from './types';

export const INITIAL_SERVICE_CATEGORIES: ServiceCategory[] = [
  {
    id: 'implants',
    name: 'Implantes Dentales',
    services: [
      { id: 'implant_single', name: 'Implante Dental Unitario', price: 3500, category: 'Implantes Dentales' },
    ],
  },
  {
    id: 'rehab_implants',
    name: 'Rehabilitación sobre Implantes',
    services: [
      { id: 'rehab_attachments', name: 'Aditamentos Protésicos', price: 700, category: 'Rehabilitación sobre Implantes' },
      { id: 'rehab_crowns_on_implants', name: 'Coronas sobre Implantes', price: 2000, category: 'Rehabilitación sobre Implantes' },
      { id: 'rehab_bridges_on_implants', name: 'Puentes sobre Implantes (por pieza)', price: 1800, category: 'Rehabilitación sobre Implantes' },
      { id: 'rehab_removable_prosthesis_on_implants', name: 'Prótesis Removible sobre Implantes', price: 4000, category: 'Rehabilitación sobre Implantes' },
    ],
  },
  {
    id: 'restorations',
    name: 'Restauraciones con Resina',
    services: [
      { id: 'resin_simple', name: 'Simple', price: 200, category: 'Restauraciones con Resina' },
      { id: 'resin_composite', name: 'Compuesta', price: 300, category: 'Restauraciones con Resina' },
      { id: 'resin_complex', name: 'Compleja', price: 400, category: 'Restauraciones con Resina' },
    ],
  },
  {
    id: 'fixed_prosthesis',
    name: 'Prótesis Fija',
    services: [
      { id: 'prosthesis_porcelain_crown', name: 'Corona en Porcelana', price: 1500, category: 'Prótesis Fija' },
      { id: 'prosthesis_zirconia_crown', name: 'Corona en Zirconio', price: 2500, category: 'Prótesis Fija' },
    ],
  },
];

export const ADMIN_PASSWORD = "admin"; // Simulated password
export const WHATSAPP_NUMBER = "59170639003"; // Updated WhatsApp number
export const CONTACT_EMAIL = "biodenslp@gmail.com"; // Updated email
export const CLINIC_NAME = "odontologia.com.bo"; // Updated clinic name
export const CLINIC_ADDRESS = "av. arce 2177 edificio real conventions piso 7 of 719"; // Updated address

export const AVAILABLE_TIME_SLOTS = [
  "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
  "14:00", "14:30", "15:00", "15:30", "16:00", "16:30"
];
