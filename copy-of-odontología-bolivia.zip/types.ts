
export interface DentalService {
  id: string;
  name: string;
  price: number; // in Bolivianos (Bs)
  category: string;
}

export interface ServiceCategory {
  id: string;
  name: string;
  services: DentalService[];
}

export interface Appointment {
  id: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  patientName: string;
  patientContact?: string; 
}

export interface SelectedService {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

export interface GeneratedBudget {
  id: string;
  createdAt: string; // ISO date string
  items: SelectedService[];
  totalAmount: number;
  patientName?: string;
}

export interface PatientInfo {
  name: string;
  age: string;
  phone: string;
  email: string;
}

export interface UploadedFile {
  id: string;
  name: string;
  type: string; // e.g., 'prescription', 'clinical_image'
  file: File;
  previewUrl?: string; // For images
}
