
import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import HomePage from './pages/HomePage';
import BookingPage from './pages/BookingPage';
import BudgetPage from './pages/BudgetPage';
import ProfilePage from './pages/ProfilePage';
import AdminLoginPage from './pages/AdminLoginPage';
import AdminDashboardPage from './pages/AdminDashboardPage';
import BottomNavBar from './components/BottomNavBar';
import { useAppContext } from './contexts/AppContext';

const App: React.FC = () => {
  const { isAdminLoggedIn } = useAppContext();

  return (
    <HashRouter>
      <div className="flex flex-col h-screen bg-gray-50">
        <main className="flex-grow overflow-y-auto pb-16"> {/* padding-bottom to avoid overlap with fixed nav bar */}
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/booking" element={<BookingPage />} />
            <Route path="/budget" element={<BudgetPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/admin-login" element={<AdminLoginPage />} />
            <Route 
              path="/admin" 
              element={isAdminLoggedIn ? <AdminDashboardPage /> : <Navigate to="/admin-login" />} 
            />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>
        <BottomNavBar />
      </div>
    </HashRouter>
  );
};

export default App;
