
import React from 'react';
import { NavLink } from 'react-router-dom';
import { HomeIcon } from './icons/HomeIcon';
import { CalendarIcon } from './icons/CalendarIcon';
import { CalculatorIcon } from './icons/CalculatorIcon';
import { UserIcon } from './icons/UserIcon';
import { AdminIcon } from './icons/AdminIcon';
import { useAppContext } from '../contexts/AppContext';

const BottomNavBar: React.FC = () => {
  const { isAdminLoggedIn } = useAppContext();

  const navItems = [
    { path: '/', label: 'Inicio', icon: <HomeIcon className="w-6 h-6" /> },
    { path: '/booking', label: 'Agendar', icon: <CalendarIcon className="w-6 h-6" /> },
    { path: '/budget', label: 'Presupuesto', icon: <CalculatorIcon className="w-6 h-6" /> },
    { path: '/profile', label: 'Perfil', icon: <UserIcon className="w-6 h-6" /> },
  ];

  if (isAdminLoggedIn) {
    navItems.push({ path: '/admin', label: 'Admin', icon: <AdminIcon className="w-6 h-6" /> });
  } else {
     navItems.push({ path: '/admin-login', label: 'Admin', icon: <AdminIcon className="w-6 h-6" /> });
  }

  const activeClassName = "text-blue-600";
  const inactiveClassName = "text-gray-500 hover:text-blue-500";

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg">
      <div className="max-w-md mx-auto flex justify-around items-center h-16">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) => 
              `flex flex-col items-center justify-center p-2 transition-colors duration-200 ease-in-out ${isActive ? activeClassName : inactiveClassName}`
            }
          >
            {item.icon}
            <span className="text-xs mt-1">{item.label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
};

export default BottomNavBar;
