
import React from 'react';
import { DentalService, SelectedService } from '../types';

interface ServiceCategoryProps {
  categoryName: string;
  services: DentalService[];
  selectedServices: SelectedService[];
  onServiceToggle: (service: DentalService, quantity: number) => void;
}

const ServiceCategoryComponent: React.FC<ServiceCategoryProps> = ({ categoryName, services, selectedServices, onServiceToggle }) => {
  return (
    <div className="mb-6 p-4 bg-white rounded-lg shadow">
      <h3 className="text-xl font-semibold text-blue-700 mb-3 border-b pb-2">{categoryName}</h3>
      {services.map(service => {
        const currentSelection = selectedServices.find(s => s.id === service.id);
        const quantity = currentSelection ? currentSelection.quantity : 0;

        return (
          <div key={service.id} className="flex justify-between items-center py-2 border-b border-gray-100 last:border-b-0">
            <div>
              <label htmlFor={service.id} className="text-gray-700 cursor-pointer select-none">
                {service.name} - <span className="text-sm text-gray-500">{service.price} Bs.</span>
              </label>
            </div>
            <div className="flex items-center">
              <button
                onClick={() => onServiceToggle(service, Math.max(0, quantity - 1))}
                className="px-2 py-1 bg-gray-200 text-gray-700 rounded-l hover:bg-gray-300 disabled:opacity-50"
                disabled={quantity === 0}
              >
                -
              </button>
              <input
                type="number"
                id={service.id}
                value={quantity}
                readOnly 
                className="w-10 text-center border-t border-b border-gray-200 focus:outline-none"
                aria-label={`Cantidad para ${service.name}`}
              />
              <button
                onClick={() => onServiceToggle(service, quantity + 1)}
                className="px-2 py-1 bg-gray-200 text-gray-700 rounded-r hover:bg-gray-300"
              >
                +
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default ServiceCategoryComponent;
