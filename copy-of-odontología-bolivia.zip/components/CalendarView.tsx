
import React, { useState, useMemo } from 'react';
import { format, addMonths, subMonths, startOfMonth, endOfMonth, startOfWeek, endOfWeek, eachDayOfInterval, isSameMonth, isSameDay, getDay, addDays } from 'date-fns';
import { es } from 'date-fns/locale';

interface CalendarViewProps {
  selectedDate: Date | null;
  onDateSelect: (date: Date) => void;
  availableSlots?: string[]; // e.g., ["09:00", "10:00"]
  selectedSlot?: string | null;
  onSlotSelect?: (slot: string) => void;
}

const CalendarView: React.FC<CalendarViewProps> = ({ selectedDate, onDateSelect, availableSlots, selectedSlot, onSlotSelect }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const daysOfWeek = useMemo(() => {
    const start = startOfWeek(new Date(), { locale: es });
    return Array.from({ length: 7 }).map((_, i) => format(addDays(start, i), 'EE', { locale: es }));
  }, []);

  const monthDays = useMemo(() => {
    const monthStart = startOfMonth(currentMonth);
    const monthEnd = endOfMonth(currentMonth);
    const startDate = startOfWeek(monthStart, { locale: es });
    const endDate = endOfWeek(monthEnd, { locale: es });
    return eachDayOfInterval({ start: startDate, end: endDate });
  }, [currentMonth]);

  const handlePrevMonth = () => setCurrentMonth(subMonths(currentMonth, 1));
  const handleNextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));

  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <div className="flex justify-between items-center mb-4">
        <button onClick={handlePrevMonth} className="p-2 rounded-full hover:bg-gray-100 text-blue-600">
          &lt;
        </button>
        <h3 className="text-lg font-semibold text-gray-700 capitalize">
          {format(currentMonth, 'MMMM yyyy', { locale: es })}
        </h3>
        <button onClick={handleNextMonth} className="p-2 rounded-full hover:bg-gray-100 text-blue-600">
          &gt;
        </button>
      </div>
      <div className="grid grid-cols-7 gap-1 text-center text-sm text-gray-600 mb-2">
        {daysOfWeek.map(day => <div key={day} className="font-medium capitalize">{day.substring(0,3)}</div>)}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {monthDays.map((day, index) => (
          <button
            key={index}
            onClick={() => onDateSelect(day)}
            disabled={!isSameMonth(day, currentMonth)}
            className={`
              p-2 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-400
              ${!isSameMonth(day, currentMonth) ? 'text-gray-300 cursor-not-allowed' : 'hover:bg-sky-100'}
              ${selectedDate && isSameDay(day, selectedDate) ? 'bg-blue-500 text-white font-semibold' : 'text-gray-700'}
              ${isSameDay(day, new Date()) && !(selectedDate && isSameDay(day, selectedDate)) ? 'ring-2 ring-sky-300' : ''}
            `}
          >
            {format(day, 'd')}
          </button>
        ))}
      </div>
      {selectedDate && availableSlots && onSlotSelect && (
        <div className="mt-4">
          <h4 className="text-md font-semibold text-gray-700 mb-2">Horarios Disponibles para {format(selectedDate, 'PPP', { locale: es })}:</h4>
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
            {availableSlots.map(slot => (
              <button
                key={slot}
                onClick={() => onSlotSelect(slot)}
                className={`
                  p-2 rounded-md text-sm border
                  ${selectedSlot === slot ? 'bg-blue-500 text-white border-blue-500' : 'bg-gray-50 text-blue-600 border-gray-300 hover:bg-sky-100'}
                `}
              >
                {slot}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default CalendarView;
